import requests
import re
import spider.PageFormat as pf
import time
import sqlite3

url_0 = 'http://www.nbegame.net/forum-45-{page}.html'
sql_insert = "insert into page_info (title, author, cate, url, date) " \
             "values {};"

conn = sqlite3.connect("nbe_db.db")
cursor = conn.cursor()
cursor.execute("create table if not exists page_info("
               "id int primary key, "
               "title text, "
               "author text, "
               "cate text, "
               "url text, "
               "date text)")

for i in range(216):
    url = url_0.format(page=i+1)
    r = requests.get(url)
    r = r.text
    page_object = pf.PageFormat(r)
    list0 = page_object.format_output()
    for line in list0:
        cursor.execute(sql_insert.format(line))
        print(line)

    conn.commit()
    time.sleep(1)

cursor.close()
conn.close()
