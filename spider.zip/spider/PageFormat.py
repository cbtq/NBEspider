import re


class PageFormat:
    def __init__(self, page_html):
        self.page = page_html

    def text_list(self):
        text_list = re.findall(r'<tbody id="normalthread([\d\D]*?)</tbody>', self.page)
        return text_list

    def list(self, i):
        i_title = re.findall(r'<a href="http://www\.nbegame\.net/thread[\d\D]*class="tit">([\d\D]*?)</a>', i)
        i_author_pre = re.findall(r'<span class="user">([\d\D]*?)</span>', i)
        i_author = re.findall(r'<a href="http://www\.nbegame\.net/space-uid-[\d\D]*?>([\d\D]*?)</a>', i_author_pre[0])
        i_cate = re.findall(r'typeid=\d{2,3}">(\S{2})</a>', i)
        i_url = re.findall(r'<a href="(http://www.nbegame\.net/thread[-\d]*?\.html)"[\d\D]*?onclick="atarget\(this\)" '
                           r'class="tit">', i)
        i_date = re.findall(r'<span[\d\D]*?"time"[\d\D]*?(20[\d]{2}-[\d]{1,2}-[\d]{1,2})[\d\D]*?</span>', i)
        if not i_author:
            i_author = ['神秘人士', ]
        return i_title[0], i_author[0], i_cate[0], i_url[0], i_date[0]

    def format_output(self):
        text_list = self.text_list()
        formatter = []
        for i in text_list:
            line = self.list(i)
            formatter.append(line)
        return formatter
