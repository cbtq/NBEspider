import sqlite3
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt



class Stat:
    def __init__(self, db_name):
        self.dbname = db_name
        self.conn = sqlite3.connect(self.dbname)
        self.cursor = self.conn.cursor()

    def read_au(self):
        sql_read = "select author from page_info;"
        self.cursor.execute(sql_read)
        au_list = [tuple[0] for tuple in self.cursor.fetchall()]
        return au_list

    def author_cal(self):
        pass


if __name__ == '__main__':
    a = Stat("nbe_db - 副本.db")
    list1 = a.read_au()
    li_count = pd.value_counts(list1)
    print(li_count.to_dict())
    plt.rcParams['font.sans-serif']=['SimHei'] #显示中文标签
    fig, ax = plt.subplots()
    ax.bar(li_count.index[1:30], li_count.values[1:30])
    ax.set_xlabel("ID")  # 设置x轴标签
    plt.xticks(rotation=45)
    ax.set_ylabel("发帖数")  # 设置y轴标签
    ax.set_title("NBE论坛数据可视化")  # 设置标题
    # ax.set_xlim(1979, 2011)  # 设置x轴数据限值
    plt.show()  # 显示图像
